package booksort;

import java.util.Scanner;
import exceptions.QueueEmptyException;
import exceptions.QueueFullException;
import exceptions.StackEmptyException;
import exceptions.StackFullException;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author Levy Swartz
 * @version 1.0
 * @since 1.0
*/

public class GameController {
	
	//create a new Book object
	public static Book createBook(int num) {
		
		Book book = new Book(num + 1, generateBookColor());
		
		//return Book object
		return book;
	}
	
	//create a new customer based on a Stack data structure
	public static Stack createCustomer(int sizeRange) throws StackFullException, StackEmptyException  {
		//create customer object
		Stack customer = new Stack(sizeRange);
		
		for(int i = 0; i < sizeRange; ++i) {
			//push books to Stack
			customer.push(createBook(i));
		}
		
		//return customer Stack object
		return customer;
	}
	
	//randomly generates a color for a Book object
	public static String generateBookColor() {
		//declare variables
		String color = "";
		//generate number to choose one of 8 colors
		int num = (int)((Math.random() * 8) + 1);  //1 to 8
		
		switch (num){
			case 1:
				//red
				color = "red";
				break;
			case 2:
				//orange
				color = "orange";
				break;
			case 3:
				//yellow
				color = "yellow";
				break;
			case 4:
				//green
				color = "green";
				break;
			case 5:
				//blue
				color = "blue";
				break;
			case 6:
				//purple
				color = "purple";
				break;
			case 7:
				//pink
				color = "pink";
				break;
			case 8:
				//brown
				color = "brown";
				break;
		}
		
		//return color for Book object
		return color;
	}
	
	//generates a Stack to represent the order goal to for the player to sort towards
	public static String[] generateRequestedStack(String[] requestedStack, Stack currCustomer) throws StackEmptyException {
		//create array version of the Stack
		String[] currCustomerArr = new String[currCustomer.size()];
		
		//put book colors in array
		for(int i = 0; i < currCustomerArr.length; ++i) {
			currCustomerArr[i] = currCustomer.peek().getBookColor();
			currCustomer.pop();
		}
		
		//shuffle array
		List<String> list = Arrays.asList(currCustomerArr);
		Collections.shuffle(list);
		list.toArray(currCustomerArr);
		
		//put shuffled array in requestedStack array
		for(int i = 0; i < currCustomerArr.length; ++i) {
			requestedStack[i] = currCustomerArr[i];
		}
		
		//return requestedStack
		return requestedStack;
	}
	
	//checks if the bookStack and the requestedStack match
	public static boolean stackIsEqual(String[] requestedStack, Stack bookStack, int sizeRange) throws StackEmptyException {
		
		if(!bookStack.isEmpty() || bookStack.size() == sizeRange) {
			for(int i = 0; i < sizeRange; ++i) {
				//check if match
				if(requestedStack[i] != bookStack.peek().getBookColor() ) {
					//if something doesn't match, return false
					return false;
				}
				//pop so next object can be peeked
				bookStack.pop();
			}
			
			//if all match, return true
			return true;
		}
		else {
			//return false if bookStack is empty
			return false;
		}
		
	}
	
	//grabs the book the player selected
	public static Book setChosenBook(Book chosen) {
		
		Book queuedBook = new Book(chosen.getId(), chosen.getBookColor());
		
		//return the Book object
		return queuedBook;
	}
	
	//resets bookStack by removing all books in it
	public static Stack resetBookStack(Stack bookStack) throws StackEmptyException {
		//pop all items in stack
		for(int i = 0; i < bookStack.size(); ++i) {
			bookStack.pop();
		}
		
		//return empty bookStack
		return bookStack;
	}
	
	//prints out all the stacks to give the player a visual to work with
	public static void printBookStack(Stack stack1, Stack stack2, Stack stack3) throws StackEmptyException {
		int size = 0;
		
		//for making it so the stacks print without any books floating
		if(size < stack1.size()) {
			size = stack1.size();
		}
		if(size < stack2.size()) {
			size = stack2.size();
		}
		if(size < stack3.size()) {
			size = stack3.size();
		}
		int largest = 0;
		
		for(int x = 1; x <= size; ++x) {
			//set largest to 0
			largest = 0;
			
			//for making it so the stacks print without any books floating
			if(largest < stack1.size()) {
				largest = stack1.size();
			}
			if(largest < stack2.size()) {
				largest = stack2.size();
			}
			if(largest < stack3.size()) {
				largest = stack3.size();
			}
			
			//print bookStack member
			if(stack1.peek() == null || stack1.isEmpty() || stack1.size() != largest) {
				System.out.print("| ");
				printBookVisual(0, "null");
				System.out.print(" | ");
			}
			else {
				System.out.print("| ");
				printBookVisual(stack1.peek().getId(), stack1.peek().getBookColor());
				System.out.print(" | ");
				stack1.pop();
			}
			//print sideStack1 member
			if(stack2.peek() == null || stack2.isEmpty() || stack2.size() != largest) {
				printBookVisual(0, "null");
				System.out.print(" | ");
			}
			else {
				printBookVisual(stack2.peek().getId(), stack2.peek().getBookColor());
				System.out.print(" | ");
				stack2.pop();
			}
			//print sideStack2 member
			if(stack3.peek() == null || stack3.isEmpty() || stack3.size() != largest) {
				printBookVisual(0, "null");
				System.out.print(" |\n");
			}
			else {
				printBookVisual(stack3.peek().getId(), stack3.peek().getBookColor());
				System.out.print(" |\n");
				stack3.pop();
			}
			
		}
	}
	
	//prints a visual of a Book object
	public static void printBookVisual(int id, String color) {
		//declare string
		String bookString = "";
		//Books must look like =1=red==
		
		switch (color){
			case "red":
				//red
				bookString = "=" + id + "=red==";
				break;
			case "orange":
				//orange
				bookString = "=" + id + "=org==";
				break;
			case "yellow":
				//yellow
				bookString = "=" + id + "=ylw==";
				break;
			case "green":
				//green
				bookString = "=" + id + "=grn==";
				break;
			case "blue":
				//blue
				bookString = "=" + id + "=blu==";
				break;
			case "purple":
				//purple
				bookString = "=" + id + "=prp==";
				break;
			case "pink":
				//pink
				bookString = "=" + id + "=pnk==";
				break;
			case "brown":
				//brown
				bookString = "=" + id + "=bwn==";
				break;
				
			default:
				//null values replace books with empty space
				bookString = "--------";
				break;
		}
		
		//print book
		System.out.print(bookString);
	}

	public static void main(String[] args) throws StackFullException, StackEmptyException, QueueEmptyException, CloneNotSupportedException {
		//declare variables
		int size = 0;
		int sizeRange = 5;
		String[] requestedStack = new String[sizeRange];
		//user inputs
		String userInput = "";
		String next = "x";
		//book queries
		Stack bookStackCheck = null; 
		boolean skip = false;
		Book chosenBook = new Book();
		int returnBook = 0;
		//create Scanner
		Scanner sc = new Scanner(System.in);
		
		//create 3 stacks for book arrangement
		Stack bookStack = new Stack();
		Stack sideStack1 = new Stack();
		Stack sideStack2 = new Stack();
		
		//create customer queue
		int num = (int)((Math.random() * 10) + 3);  //3 to 12 customers
		Queue customers = new Queue(num);
		
		for(int i = 0; i < num; ++i) {
			//add customer to the queue
			try {
				customers.enqueue(createCustomer(sizeRange));
			} 
			catch (QueueFullException e) {
				e.printStackTrace();
			}
		}
		
		//set the size variable for the gameplay loop
		size = customers.size();
		
		//explain game
		while(!next.equals("C") || !next.equals("c")) {
			System.out.println("Welcome to Book Sort!");
			System.out.println("There is a line of customers that need you to sort their books for them.");
			System.out.println("The customers will tell you how they want their books sorted.");
			System.out.println("There are 3 stacks you can move books between");
			System.out.println("All books must be in Stack-1 in order to progress.");
			System.out.println("Enter 'C' to continue");
			next = sc.nextLine();
			
			//break loop when 'C' is detected
			if(next.equals("C") || next.equals("c")) {
				break;
			}
		}
		
		//main gameplay loop
		for(int i = 0; i < size; ++i) {
			
			//tell customer queue size
			System.out.println("\nThere are " + customers.size() + " customers in line...\n");
			
			//add current customer's stack to the book stack
			bookStack = (Stack)customers.peek().clone(); 
			
			// remove requestedStack from method
			requestedStack = generateRequestedStack(requestedStack, customers.peek());
			
			//print customer dialouge
			System.out.println("Customer " + (i + 1) + ": Hello! I am a customer looking to have my books sorted in this order:");
			
			//loop until player sort's stack equal to requested stack
			bookStackCheck = (Stack)bookStack.clone(); 
			
			//loop until requestedStack and bookStack equal each other
			//all Book objects must be be in bookStack in order to pass the check
			while(!stackIsEqual(requestedStack, bookStackCheck, sizeRange)) {
				
				//display requested stack
				System.out.print("Top - ");
				for(int x = 0; x < requestedStack.length; ++x) {
					if(requestedStack[x] != null) {
						System.out.print(requestedStack[x] + " - ");
					}
				}
				System.out.println("Bottom\n");
				
				//display book stacks
				Stack bookStackClone = (Stack)bookStack.clone(); 
				Stack sideStack1Clone = (Stack)sideStack1.clone(); 
				Stack sideStack2Clone = (Stack)sideStack2.clone(); 

				System.out.println("__Stack-1_____Stack-2_____Stack-3__");
				printBookStack(bookStackClone, sideStack1Clone, sideStack2Clone);
				System.out.println("_______________bottom_______________");
				
				//get user input to grab a book
				System.out.print("Choose a book to grab(Use: '1', '2', '3'): ");
				userInput = sc.nextLine();
				
				switch(userInput) {
					//grab from Stack 1
					case "1":
						if(!bookStack.isEmpty()) {
							chosenBook = setChosenBook(bookStack.peek());
							bookStack.pop();
							returnBook = 1;
						}
						else {
							//for if bookStack is empty
							System.out.println("There are no books in this stack");
							skip = true;
						}
						break;
					//grab from Stack 2
					case "2":
						if(!sideStack1.isEmpty()) {
							chosenBook = setChosenBook(sideStack1.peek());
							sideStack1.pop();
							returnBook = 2;
						}
						else {
							//for if sideStack1 is empty
							System.out.println("There are no books in this stack");
							skip = true;
						}
						break;
					//grab from Stack 3
					case "3":
						if(!sideStack2.isEmpty()) {
							chosenBook = setChosenBook(sideStack2.peek());
							sideStack2.pop();
							returnBook = 3;
						}
						else {
							//for if sideStack2 is empty
							System.out.println("There are no books in this stack");
							skip = true;
						}
						break;
					//prevents invalid input
					default:
						System.out.println("Not valid input");
						skip = true;
						break;
				}
				
				//skip if no book was pulled out of a stack
				if(!skip) {
					//get user input to put that book in a stack
					System.out.print("Choose where to put the book(Use: '1', '2', '3'): ");
					userInput = sc.nextLine();
					
					switch(userInput) {
						//put book in Stack 1
						case "1":
							bookStack.push(chosenBook);
							break;
						//put book in Stack 2
						case "2":
							sideStack1.push(chosenBook);
							break;
						//put book in Stack 3
						case "3":
							sideStack2.push(chosenBook);
							break;
						//prevents invalid input
						default:
							System.out.println("Not valid input");
							//put book back in its stack
							switch(returnBook) {
								//put back in bookStack
								case 1:
									bookStack.push(chosenBook);
									break;
								//put back in sideStack1
								case 2:
									sideStack1.push(chosenBook);
									break;
								//put back in sideStack2
								case 3:
									sideStack2.push(chosenBook);
									break;
							}
							break;
					}
				}
				skip = false;
				bookStackCheck = (Stack)bookStack.clone();
			}
			
			//remove customer from queue
			System.out.println("Customer: That's how I wanted it! Thank you!");
			customers.dequeue();
			//reset bookStack
			bookStack = resetBookStack(bookStack);
			//allow user to choose when to move forward to avoid a wall of text
			next = "x";
			while(!next.equals("C") || !next.equals("c")) {
				System.out.println("Enter 'C' to continue");
				next = sc.nextLine();
				
				//break loop when 'C' is detected
				if(next.equals("C") || next.equals("c")) {
					break;
				}
			}
		}
		
		//end game
		System.out.println("That is all the customers for today! Thanks for playing!");
		sc.close();
	}
	
	/*Testing:
	 * - C to continue only accepts 'C' and 'c' as expected
	 * 
	 * - selecting an empty stack to grab from prints "There are no books in this stack" as expected
	 * 
	 * - selecting from a stack and putting the book in the same stack puts the book back with no errors as expexted
	 * 
	 * - invalid input on moving a book into a stack puts the book in its previous stack as expected
	 * 
	 * - visual stack interface prints correctly even when Stack-1 is empty or is small
	 * 
	 * - every time program is run, stackIsEqual properly checks if equal without doing it too early
	 */
}
