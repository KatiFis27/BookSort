package booksort;


/** 
 * @author Levy Swartz
 * @version 1.0
 * @since 1.0
*/

import exceptions.StackEmptyException;
import exceptions.StackFullException;

public class Stack implements Cloneable{
	//stack attributes
	private int top;
	private int maxSize;
	private Book stackItems[]; 
	
	
	//no-arg constructor
	public Stack() {
		//set values
		this.maxSize = 8; 
		this.top = -1; 
		this.stackItems = new Book[maxSize];
	}
	
	//constructor passes max size
	public Stack(int maxSize) {
		//set values
		this.maxSize = maxSize;
		this.top = -1; 
		this.stackItems = new Book[maxSize];
	}
	
	//check if stack is full
	public boolean isFull() {
		return top == maxSize - 1;
	}
	
	//check if stack is empty
	public boolean isEmpty() {
		/*for(int i = 0; i < this.maxSize; ++i) {
			if(stackItems[i] != null) {
				return false;
			}
		}
		return true;*/
		if(this.top >= 0) {
			return false;
		}
		return true;

	}
   
	//return stack size
	public int size() {
		
		return (top + 1);

	}
	
	//peeks at top of stack
	public Book peek() {
		if (!this.isEmpty()) {
			//System.out.println("top: " + top);
			return stackItems[top];
		}
		return null;

	}
	
	//removes top item
	public Book pop() throws StackEmptyException{
		//Book item = new Book(); 
		Book item = null; 
		if(!this.isEmpty()) {
			item = this.stackItems[top];
			this.top -= 1;
			return item;
		}
		throw new StackEmptyException(); 
	}	
	
	//adds item to top of stack
	public void push(Book item) throws StackFullException{
		if(!this.isFull()) {
			this.top += 1;
			this.stackItems[top] = item;
		}
		else {
			throw new StackFullException(); 
		}
	}
	
	//prints stack to user
	public String printStackUp() throws StackEmptyException {
		String stackString = new String(); 
		
		if(!this.isEmpty()) {
			for(int i = this.size() - 1; i >= 0; --i) {
					stackString += "Id: " + this.stackItems[i].getId() + 
								   "   Color: " + this.stackItems[i].getBookColor() + "\n";
			}
			return stackString;
		}
		else {
			return "All null";
		}
		//throw new StackEmptyException(); 
	}
	
	//for cloning stacks
	public Object clone() throws CloneNotSupportedException {
		
		return super.clone();
	}

}
