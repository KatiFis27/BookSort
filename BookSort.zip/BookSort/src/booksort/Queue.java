package booksort;

/**
 * @author Levy Swartz
 * @version 1.0
 * @since 1.0
*/

import exceptions.QueueEmptyException;
import exceptions.QueueFullException;
import exceptions.StackEmptyException;

public class Queue {
	//queue attributes
	private int head;
	private int tail;
	private int size;
	private int maxSize; 
	private Stack queueItems[];

	//no-arg constructor
	public Queue() {
		//set values
		this.maxSize = 5;
		this.size = 0;
		this.head = -1;
		this.tail = -1;
		this.queueItems = new Stack[maxSize];
		//set all items to null
		for(int i = 0; i < this.maxSize; ++i) {
			queueItems[i] = null;
		}
	}

	//constructor passes max size
	public Queue(int maxSize) {
		//set values
		this.maxSize = maxSize;
		this.size = 0;
		this.head = -1;
		this.tail = -1;
		this.queueItems = new Stack[maxSize];
		//set all items to null
		for(int i = 0; i < this.maxSize; ++i) {
			queueItems[i] = null;
		}
	}

	//check if queue is full
	public boolean isFull() {
		for(int i = 0; i < this.maxSize; ++i) {
			if(queueItems[i] == null) {
				return false;
			}
		}
		return true;
	}

	//check if queue is empty
	public boolean isEmpty() {
		for(int i = 0; i < this.maxSize; ++i) {
			if(queueItems[i] != null) {
				return false;
			}
		}
		return true;
	}

	//returns queue size
	public int size() {
        return this.size;
	}

	//peeks at queue head
	public Stack peek() throws QueueEmptyException {
		if (!this.isEmpty()) {
			return queueItems[head];
		}
		throw new QueueEmptyException(); 
	}
	
	//adds item to tail
	public void enqueue(Stack item) throws QueueFullException {
		if(!this.isFull()) {
			if(this.isEmpty()) {
				this.head += 1;
				this.tail += 1;
			}
			else {
				if(this.maxSize - 1 == this.tail) {
					this.tail = 0;
				}
				else {
					this.tail += 1;
				}
			}
			
			this.queueItems[tail] = item;
			this.size += 1;
			
			return;
		}
		throw new QueueFullException(); 
	}

	//removes head item
	public Stack dequeue() throws QueueEmptyException {
		Stack item = null;
		if(!this.isEmpty()) {
			item = this.queueItems[head];
			this.queueItems[head] = null;
			this.size -= 1;
			if(this.isEmpty()) {
				this.head = -1;
				this.tail = -1;
			}
			else {
				if(this.head == maxSize - 1) {
					this.head = 0;
				}
				else {
					this.head += 1;
				}
			}
			return item;
		}
		else {
			throw new QueueEmptyException(); 
		}
	}

	//prints queue to user
	public String printQueue() throws QueueEmptyException {
		String queueString = new String();
		if(!this.isEmpty()) {
			System.out.println(this.head + " " + this.tail);
			for(int i = this.head; i != this.tail; i++) {
				if(i >= this.maxSize) {
					i = 0;
				}
				try {
					queueString += this.queueItems[i].printStackUp() + "\n";
				} 
				catch (StackEmptyException e) {
					e.printStackTrace();
				}
			}
			try {
				queueString += this.queueItems[tail].printStackUp() + "\n";
			} 
			catch (StackEmptyException e) {
				e.printStackTrace();
			}
			
			return queueString;
		}
		else {
			throw new QueueEmptyException();
		}
	}
}