package booksort;

public class Book {
	
	//attributes
	private int id;
	private String bookColor;
	
	//no-arg constructor
	public Book() {
		this.id = 0;
		this.bookColor = "red";
	}
		
	//constructor
	public Book(int _id, String _color) {
		this.id = _id;
		this.bookColor = _color;
	}

	//getters & setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getBookColor() {
		return bookColor;
	}
	public void setBookColor(String bookColor) {
		this.bookColor = bookColor;
	}
}
