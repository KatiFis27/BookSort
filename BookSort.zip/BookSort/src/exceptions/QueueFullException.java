package exceptions;

public class QueueFullException extends Exception {

}
