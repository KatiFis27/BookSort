package exceptions;

public class QueueEmptyException extends Exception {

}
