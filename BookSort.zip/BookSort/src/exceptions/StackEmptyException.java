package exceptions;

/** 
 * @author Levy Swartz
 * @version 1.0
 * @since 1.0
*/

public class StackEmptyException extends Exception {

}
